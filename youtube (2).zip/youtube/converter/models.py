from django.db import models

class Conversion(models.Model):
    youtube_url = models.URLField()
    mp3_file = models.FileField(upload_to='conversions/mp3/', blank=True, null=True)
    mp4_file = models.FileField(upload_to='conversions/mp4/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
