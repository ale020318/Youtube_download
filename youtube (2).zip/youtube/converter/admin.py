from django.contrib import admin
from .models import Conversion

admin.site.register(Conversion)
