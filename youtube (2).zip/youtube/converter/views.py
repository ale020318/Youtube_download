from django.shortcuts import render, redirect
from yt_dlp import YoutubeDL
from .models import Conversion
from django.http import HttpResponse
import os

def home(request):
    return render(request, 'home.html')

def convert_video(request):
    if request.method == 'POST':
        url = request.POST['url']
        format = request.POST['format']  # 'mp3' or 'mp4'

        ydl_opts = {
            'format': 'bestaudio/best' if format == 'mp3' else 'best',
            'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3'}] if format == 'mp3' else [],
            'outtmpl': f'media/conversions/{format}/%(id)s.%(ext)s',
        }

        with YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(url, download=True)
            video_id = info_dict.get("id", None)
            file_path = f'media/conversions/{format}/{video_id}.{format}'

        conversion = Conversion.objects.create(youtube_url=url)
        if format == 'mp3':
            conversion.mp3_file = file_path
        else:  # format == 'mp4'
            conversion.mp4_file = file_path
        conversion.save()

        return redirect('download', conversion.id, format)

    return redirect('home')

def download(request, conversion_id, format):
    conversion = Conversion.objects.get(id=conversion_id)
    file_path = conversion.mp3_file.path if format == 'mp3' else conversion.mp4_file.path

    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="audio/mpeg" if format == 'mp3' else "video/mp4")
            response['Content-Disposition'] = f'attachment; filename={os.path.basename(file_path)}'
            return response
    return HttpResponse("File not found.")
