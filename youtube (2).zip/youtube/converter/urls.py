from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('convert/', views.convert_video, name='convert'),
    path('download/<int:conversion_id>/<str:format>/', views.download, name='download'),
]
